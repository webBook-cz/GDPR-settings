<?php return [
    'cookie_banner'   => [
        'message'             => 'Náš web potrebuje na prispôsobenie obsahu a analýzu návštevnosti váš súhlas. Súhlas vyjadríte kliknutím na tlačidlo "OK".',
        'more_info'           => 'Viac informácií',
        'advanced_settings'   => 'Nastavenie',
        'decline'             => 'Svoj súhlas môžete odmietnuť',
        'here'                => 'tu',
        'accept'              => 'OK',
    ],
    'cookie_manager'  => [
        'title' => 'Detailné nastavenie Cookies',
    ],
];
