<?php

return [
    'presets_path' => plugins_path('offline/gdpr/assets/presets'),
];